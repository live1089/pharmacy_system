CREATE TRIGGER update_expiring_medicines_on_stock_change
            AFTER UPDATE ON stock
            FOR EACH ROW
            BEGIN
                -- 更新临期药品监控数据中的库存数量和状态
                UPDATE expiring_medicines 
                SET current_stock = NEW.quantity,
                    status = CASE 
                        WHEN days_until_expiry < 0 THEN '过期'
                        ELSE '正常'
                    END,
                    last_updated = datetime('now', '+8 hours')
                WHERE batch_id = NEW.batch;
            END;

