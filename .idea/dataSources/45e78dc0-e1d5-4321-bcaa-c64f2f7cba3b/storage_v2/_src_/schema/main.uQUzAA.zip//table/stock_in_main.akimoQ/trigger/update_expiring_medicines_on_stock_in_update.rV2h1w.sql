CREATE TRIGGER update_expiring_medicines_on_stock_in_update
            AFTER UPDATE ON stock_in_main
            FOR EACH ROW
            WHEN OLD.validity != NEW.validity
            BEGIN
                -- 更新临期药品监控数据
                UPDATE expiring_medicines 
                SET expiry_date = NEW.validity,
                    days_until_expiry = CAST(julianday(NEW.validity) - julianday('now') AS INTEGER),
                    status = CASE 
                        WHEN CAST(julianday(NEW.validity) - julianday('now') AS INTEGER) < 0 THEN '过期'
                        ELSE '正常'
                    END,
                    last_updated = datetime('now', '+8 hours')
                WHERE batch_id = NEW.in_id;
            END;

