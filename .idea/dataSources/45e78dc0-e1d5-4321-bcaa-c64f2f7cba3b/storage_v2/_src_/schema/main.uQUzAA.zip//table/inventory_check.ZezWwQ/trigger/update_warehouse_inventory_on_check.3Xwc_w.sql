CREATE TRIGGER update_warehouse_inventory_on_check
            AFTER UPDATE ON inventory_check
            FOR EACH ROW
            WHEN NOT EXISTS (SELECT 1 FROM shelves_drug WHERE location_id = NEW.inventory_of_location)
            BEGIN
                -- 更新仓库库存
                UPDATE stock 
                SET quantity = NEW.recorded_quantity
                WHERE drug_id = NEW.medicine_id 
                AND location = NEW.inventory_of_location 
                AND batch = NEW.inventory_of_batches;
            END;

