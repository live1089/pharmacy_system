CREATE TRIGGER stock_out_trigger
            AFTER INSERT ON stock_out_detail
            FOR EACH ROW
            BEGIN
                -- 记录库存变化历史（出库为负数）
                INSERT INTO inventory (medicine_id, detail_id, quantity, change_date, change_type, batch_number, production_lot)
                VALUES (
                    NEW.medicine_id,
                    NEW.detail_id,
                    -NEW.quantity,
                    datetime('now', '+8 hours'),
                    '出库',
                (SELECT batch FROM stock_in_main WHERE stock_in_main.in_id = NEW.stock_batch),
                (SELECT production_lot_number FROM stock_in_main WHERE stock_in_main.in_id = NEW.stock_batch)
                );
                
                -- 更新 stock 表中的库存数量
                UPDATE stock 
                SET quantity = quantity - NEW.quantity,
                    last_update = datetime('now', '+8 hours')
                WHERE batch = NEW.stock_batch 
                AND drug_id = NEW.medicine_id
                AND location IN (
                  SELECT warehouse_shelf_id 
                  FROM stock_in_detail 
                  WHERE stock_in_detail.in_id = NEW.stock_batch
                  ORDER BY detail_id DESC
                  LIMIT 1
                );
            END;

