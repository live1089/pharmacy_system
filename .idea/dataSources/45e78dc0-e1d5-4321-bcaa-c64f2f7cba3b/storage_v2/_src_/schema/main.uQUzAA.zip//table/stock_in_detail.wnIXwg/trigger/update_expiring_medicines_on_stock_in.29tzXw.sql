CREATE TRIGGER update_expiring_medicines_on_stock_in
            AFTER INSERT ON stock_in_detail
            FOR EACH ROW
            BEGIN
                -- 插入或更新临期药品监控数据
                INSERT OR REPLACE INTO expiring_medicines 
                (batch_id, medicine_name, expiry_date, days_until_expiry, current_stock, alert_threshold, status, last_updated)
                SELECT 
                    NEW.in_id,
                    md.trade_name,
                    sm.validity,
                    CAST(julianday(sm.validity) - julianday('now') AS INTEGER),
                    NEW.actual_quantity,
                    30,
                    CASE 
                        WHEN CAST(julianday(sm.validity) - julianday('now') AS INTEGER) < 0 THEN '过期'
                        ELSE '正常'
                    END,
                    datetime('now', '+8 hours')
                FROM medicine_dic md
                JOIN purchase_detail pd ON md.dic_id = pd.medicine_id
                JOIN stock_in_main sm ON sm.in_id = NEW.in_id
                WHERE pd.detail_id = NEW.purchase_detail_id
                ORDER BY sm.in_id DESC
                LIMIT 1;
            END;

