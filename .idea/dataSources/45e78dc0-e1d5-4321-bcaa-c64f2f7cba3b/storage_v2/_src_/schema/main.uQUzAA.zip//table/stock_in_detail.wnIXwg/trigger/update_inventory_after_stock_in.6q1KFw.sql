CREATE TRIGGER update_inventory_after_stock_in
                AFTER INSERT ON stock_in_detail
                FOR EACH ROW
                BEGIN
                    -- 确保记录库存变化历史
                    INSERT INTO inventory (medicine_id, detail_id, quantity, change_date, change_type, batch_number, production_lot)
                    SELECT 
                        COALESCE((SELECT md.dic_id 
                                 FROM purchase_detail pd 
                                 JOIN medicine_dic md ON md.dic_id = pd.medicine_id 
                                 WHERE pd.detail_id = NEW.purchase_detail_id), 0),
                        NEW.detail_id,
                        NEW.actual_quantity,
                        datetime('now','+8 hours'),
                        '入库',
                    (SELECT batch FROM stock_in_main WHERE in_id = NEW.in_id),
                    (SELECT production_lot_number FROM stock_in_main WHERE in_id = NEW.in_id)
                    WHERE EXISTS (
                        SELECT 1 
                        FROM purchase_detail pd 
                        JOIN medicine_dic md ON md.dic_id = pd.medicine_id 
                        WHERE pd.detail_id = NEW.purchase_detail_id
                    );
                    
                    -- 更新或插入 stock 表中的当前库存
                    INSERT OR REPLACE INTO stock (stock_id, drug_id, batch, location, quantity, last_update)
                    VALUES (
                        (SELECT stock_id 
                                 FROM stock 
                                 WHERE batch = NEW.in_id
                                 AND location = NEW.warehouse_shelf_id), 
 --                                (SELECT IFNULL(MAX(stock_id), 0) + 1 FROM stock)),
                        (SELECT md.dic_id 
                         FROM purchase_detail pd 
                         JOIN medicine_dic md ON md.dic_id = pd.medicine_id 
                         WHERE pd.detail_id = NEW.purchase_detail_id),
                        NEW.in_id,
                        NEW.warehouse_shelf_id,
                        COALESCE((SELECT quantity FROM stock WHERE batch = NEW.in_id AND location = NEW.warehouse_shelf_id), 0) + NEW.actual_quantity,
                        datetime('now', '+8 hours')
                    );
                END;

