CREATE TRIGGER update_drug_information_shelves_on_stock_location_update
            AFTER UPDATE ON stock_in_detail
            FOR EACH ROW
            WHEN OLD.warehouse_shelf_id != NEW.warehouse_shelf_id
            BEGIN
                -- 更新 stock 表中的位置信息
                UPDATE stock
                SET location = NEW.warehouse_shelf_id,
                    last_update = datetime('now', '+8 hours')
                WHERE batch = NEW.in_id 
                AND drug_id = (
                    SELECT md.dic_id 
                    FROM purchase_detail pd 
                    JOIN medicine_dic md ON pd.medicine_id = md.dic_id 
                    WHERE pd.detail_id = NEW.purchase_detail_id
                );
                
                -- 更新 drug_information_shelves 表中的仓库库存位置信息
                UPDATE drug_information_shelves
                SET warehouse_inventory_location = (
                    SELECT GROUP_CONCAT(wsp.location, ', ')
                    FROM stock s
                    JOIN warehouse_shelf_position wsp ON s.location = wsp.warehouse_shelf_id
                    WHERE s.drug_id = (
                        SELECT md.dic_id 
                        FROM purchase_detail pd 
                        JOIN medicine_dic md ON pd.medicine_id = md.dic_id 
                        WHERE pd.detail_id = NEW.purchase_detail_id
                    )
                )
                WHERE drug_information_shelves_id = (
                    SELECT md.dic_id 
                    FROM purchase_detail pd 
                    JOIN medicine_dic md ON pd.medicine_id = md.dic_id 
                    WHERE pd.detail_id = NEW.purchase_detail_id
                );
            END;

