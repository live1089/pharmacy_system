CREATE TRIGGER update_drug_information_shelves_on_shelf_delete
            AFTER DELETE ON shelves_drug
            FOR EACH ROW
            BEGIN
                INSERT OR REPLACE INTO drug_information_shelves 
                (drug_information_shelves_id, drug, expiration_date, purchase_date, shelves_sum, 
                 warehouse_inventory_sum, shelves_location, warehouse_inventory_location, approval_number, manufacturer, batch, supplier)
                SELECT 
                    md.dic_id,
                    md.trade_name,
                    sm.validity,
                    po.order_date,
                    COALESCE((SELECT SUM(shelves_number) 
                             FROM shelves_drug 
                             WHERE drug = OLD.drug), 0),
                    COALESCE((SELECT SUM(quantity) 
                             FROM stock 
                             WHERE drug_id = OLD.drug), 0),
                    COALESCE(wsp.location, ''),
                    COALESCE((SELECT GROUP_CONCAT(wsp2.location, ', ') 
                    FROM warehouse_shelf_position wsp2 
                    JOIN stock s ON s.location = wsp2.warehouse_shelf_id 
                    WHERE s.drug_id = OLD.drug), ''),
                    md.approval_number,
                    md.manufacturer,
                    sm.batch,
                    su.name
                FROM medicine_dic md
                JOIN stock_out_detail sod ON md.dic_id = sod.medicine_id
                JOIN stock_in_main sm ON sod.stock_batch = sm.in_id
                JOIN purchase_order po ON sm.order_id = po.order_id
                JOIN supplier su ON po.supplier_id = su.supplier_id
                LEFT JOIN warehouse_shelf_position wsp ON OLD.location_id = wsp.warehouse_shelf_id
                WHERE sod.detail_id = OLD.out_batch
                AND md.dic_id = OLD.drug
                LIMIT 1;
            END;

