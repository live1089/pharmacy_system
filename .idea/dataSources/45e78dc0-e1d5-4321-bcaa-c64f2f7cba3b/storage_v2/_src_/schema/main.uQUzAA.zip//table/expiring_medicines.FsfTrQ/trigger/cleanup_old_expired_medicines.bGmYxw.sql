CREATE TRIGGER cleanup_old_expired_medicines
            AFTER UPDATE ON expiring_medicines
            FOR EACH ROW
            WHEN NEW.days_until_expiry < -365
            BEGIN
                DELETE FROM expiring_medicines 
                WHERE expiring_medicine_id = NEW.expiring_medicine_id;
            END;

