CREATE TRIGGER insert_shelves_inventory_on_check
            AFTER INSERT ON inventory_check
            FOR EACH ROW
            WHEN EXISTS (SELECT 1 FROM shelves_drug WHERE location_id = NEW.inventory_of_location)
            BEGIN
                -- 更新上架库存
                UPDATE shelves_drug 
                SET shelves_number = NEW.recorded_quantity
                WHERE drug = NEW.medicine_id 
                AND location_id = NEW.inventory_of_location;
            END;

