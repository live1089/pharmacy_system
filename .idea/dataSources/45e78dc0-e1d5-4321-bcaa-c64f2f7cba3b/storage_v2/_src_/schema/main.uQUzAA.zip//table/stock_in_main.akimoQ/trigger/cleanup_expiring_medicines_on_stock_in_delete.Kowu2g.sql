CREATE TRIGGER cleanup_expiring_medicines_on_stock_in_delete
            AFTER DELETE ON stock_in_main
            FOR EACH ROW
            BEGIN
                -- 删除对应的临期药品监控记录
                DELETE FROM expiring_medicines 
                WHERE batch_id = OLD.in_id;

                -- 删除对应的库存记录
                DELETE FROM stock
                WHERE batch = OLD.in_id;

                -- 删除对应的入库明细记录
                DELETE FROM stock_in_detail
                WHERE in_id = OLD.in_id;
            END;

