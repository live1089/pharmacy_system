CREATE TRIGGER update_inventory_after_stock_out_delete
            AFTER DELETE ON stock_out_detail
            FOR EACH ROW
            BEGIN
                -- 记录库存变化历史（删除出库记录，相当于减少出库量）
                INSERT INTO inventory (medicine_id, detail_id, quantity, change_date, change_type, batch_number, production_lot)
                VALUES (
                    OLD.medicine_id,
                    OLD.detail_id,
                    OLD.quantity,  -- 正数表示库存增加（因为删除了出库记录）
                    datetime('now', '+8 hours'),
                    '出库删除',
                    (SELECT batch FROM stock_in_main WHERE in_id = OLD.stock_batch),
                    (SELECT production_lot_number FROM stock_in_main WHERE in_id = OLD.stock_batch)
                );

                -- 更新 stock 表中的库存数量（增加库存，因为删除了出库记录）
                UPDATE stock 
                SET quantity = quantity + OLD.quantity,
                    last_update = datetime('now', '+8 hours')
                WHERE batch = OLD.stock_batch 
                AND drug_id = OLD.medicine_id
                AND location IN (
                  SELECT warehouse_shelf_id 
                  FROM stock_in_detail 
                  WHERE in_id = OLD.stock_batch
                  ORDER BY detail_id DESC
                  LIMIT 1
                );
            END;

