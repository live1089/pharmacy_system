CREATE TRIGGER update_expiring_medicines_on_stock_adjustment
            AFTER UPDATE ON stock
            FOR EACH ROW
            BEGIN
                -- 更新临期药品监控数据中的库存数量
                UPDATE expiring_medicines 
                SET current_stock = NEW.quantity,
                    status = CASE 
                        WHEN days_until_expiry < 0 THEN '过期'
                        ELSE '正常'
                    END,
                    last_updated = datetime('now', '+8 hours')
                WHERE batch_id = NEW.batch;
                
                -- 更新 drug_information_shelves 表中的仓库库存数量
                UPDATE drug_information_shelves
                SET warehouse_inventory_sum = (
                    SELECT COALESCE(SUM(s.quantity), 0)
                    FROM stock s
                    WHERE s.drug_id = NEW.drug_id
                )
                WHERE drug_information_shelves_id = NEW.drug_id;
            END;

