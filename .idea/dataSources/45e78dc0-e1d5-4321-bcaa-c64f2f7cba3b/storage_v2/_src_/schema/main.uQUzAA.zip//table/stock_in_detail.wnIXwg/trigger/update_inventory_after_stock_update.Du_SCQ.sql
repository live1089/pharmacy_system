CREATE TRIGGER update_inventory_after_stock_update
             AFTER UPDATE ON stock_in_detail
             FOR EACH ROW
             BEGIN
                 -- 更新库存变化历史
                 INSERT INTO inventory (medicine_id, detail_id, quantity, change_date, change_type)
                 SELECT 
                     (SELECT md.dic_id 
                      FROM purchase_detail pd 
                      JOIN medicine_dic md ON md.dic_id = pd.medicine_id 
                      WHERE pd.detail_id = NEW.purchase_detail_id),
                     NEW.detail_id,
                     NEW.actual_quantity - OLD.actual_quantity,  -- 只记录变化量
                     datetime('now','+8 hours'),
                     '库存调整'
                 WHERE EXISTS (
                     SELECT 1 
                     FROM purchase_detail pd 
                     JOIN medicine_dic md ON md.dic_id = pd.medicine_id 
                     WHERE pd.detail_id = NEW.purchase_detail_id
                 );

                 -- 更新 stock 表中的当前库存
                 UPDATE stock 
                 SET quantity = quantity + (NEW.actual_quantity - OLD.actual_quantity),
                       drug_id = (SELECT md.dic_id 
                        FROM purchase_detail pd 
                        JOIN medicine_dic md ON md.dic_id = pd.medicine_id 
                        WHERE pd.detail_id = NEW.purchase_detail_id),
                     last_update = datetime('now', '+8 hours')
                 WHERE batch = NEW.in_id AND location = NEW.warehouse_shelf_id;
             END;

