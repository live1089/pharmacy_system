CREATE TRIGGER update_shelves_location_on_shelf_update
            AFTER UPDATE ON shelves_drug
            FOR EACH ROW
            WHEN OLD.location_id != NEW.location_id OR OLD.drug != NEW.drug
            BEGIN
                -- 更新新药品的位置信息
                UPDATE drug_information_shelves 
                SET shelves_location = COALESCE((SELECT location 
                                                FROM warehouse_shelf_position 
                                                WHERE warehouse_shelf_id = NEW.location_id), '')
                WHERE drug_information_shelves_id = NEW.drug;
        
                -- 如果药品ID也改变了，更新旧药品的位置信息
                UPDATE drug_information_shelves 
                SET shelves_location = COALESCE((SELECT location 
                                                FROM warehouse_shelf_position 
                                                WHERE warehouse_shelf_id = OLD.location_id), '')
                WHERE drug_information_shelves_id = OLD.drug AND OLD.drug != NEW.drug;
            END;

