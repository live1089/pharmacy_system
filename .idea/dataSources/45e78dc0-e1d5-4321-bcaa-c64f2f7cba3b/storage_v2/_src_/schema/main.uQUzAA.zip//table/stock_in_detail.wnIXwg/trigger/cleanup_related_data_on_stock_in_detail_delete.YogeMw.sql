CREATE TRIGGER cleanup_related_data_on_stock_in_detail_delete
            AFTER DELETE ON stock_in_detail
            FOR EACH ROW
            BEGIN
                -- 删除对应的库存记录
                DELETE FROM stock
                WHERE batch = OLD.in_id AND location = OLD.warehouse_shelf_id;

                -- 删除对应的临期药品监控记录（如果该批次没有其他明细记录）
                DELETE FROM expiring_medicines 
                WHERE batch_id = OLD.in_id 
                AND NOT EXISTS (
                    SELECT 1 FROM stock_in_detail WHERE in_id = OLD.in_id
                );
            END;

